// @ts-nocheck
sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sapui5agendar.scotimerecording_html.controller.App", {
        onInit: function () {
        }
      });
    }
  );
  