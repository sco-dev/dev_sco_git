sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("SCO.sco00timerecording_html.controller.App", {
        onInit: function () {
        }
      });
    }
  );
  